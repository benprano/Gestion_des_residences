package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="ETUDIANT")
public class Etudiant implements Serializable {
	@Id
	@Column(name="MATRICULE_ETUDIANT")
    private String id_etudiant;
	@Column(name="NOM_ETUDIANT")
	private String nom_etudiant;
	@Column(name="PRENOM")
	private String prenom_etudiant;
	@Column(name="SEXE")
	private String sexe;
	@Column(name="DATE_NAISSANCE")
	private Date date_naissance;
	@Column(name="LIEU_NAISSANCE")
	private String lieu_naissance;
	@Column(name="ADRESSE")
	private String adresse;
	@Column(name="NATIONALITE")
	private String nationalite;
	@Column(name="UNIVERSITE")
	private String universite;
	@Column(name="FILIERE")
	private String filiere;
	@Column(name="EMAIL")
	private String email;
	@Column(name="TELEPHONE")
	private String telephone;
	@Column(name="PHOTO")
	private String photo;
	
	@OneToMany(mappedBy="etudiant")
	private List<Operations> operation;
	
	@OneToMany(mappedBy="etudiants")
	private List<Affecter> affecter;
	
	@OneToMany(mappedBy="etudiants")
	private List<Inscrire> inscrire;
	
	public String getId_etudiant() {
		return id_etudiant;
	}
	public void setId_etudiant(String id_etudiant) {
		this.id_etudiant = id_etudiant;
	}
	public String getNom_etudiant() {
		return nom_etudiant;
	}
	public void setNom_etudiant(String nom_etudiant) {
		this.nom_etudiant = nom_etudiant;
	}
	public String getPrenom_etudiant() {
		return prenom_etudiant;
	}
	public void setPrenom_etudiant(String prenom_etudiant) {
		this.prenom_etudiant = prenom_etudiant;
	}
	public String getSexe() {
		return sexe;
	}
	public void setSexe(String sexe) {
		this.sexe = sexe;
	}
	public Date getDate_naissance() {
		return date_naissance;
	}
	public void setDate_naissance(Date date_naissance) {
		this.date_naissance = date_naissance;
	}
	public String getLieu_naissance() {
		return lieu_naissance;
	}
	public void setLieu_naissance(String lieu_naissance) {
		this.lieu_naissance = lieu_naissance;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getNationalite() {
		return nationalite;
	}
	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}
	public String getUniversite() {
		return universite;
	}
	public void setUniversite(String universite) {
		this.universite = universite;
	}
	public String getFiliere() {
		return filiere;
	}
	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public List<Operations> getOperation() {
		return operation;
	}
	public void setOperation(List<Operations> operation) {
		this.operation = operation;
	}
	
	public List<Affecter> getAffecter() {
		return affecter;
	}
	public void setAffecter(List<Affecter> affecter) {
		this.affecter = affecter;
	}
	public List<Inscrire> getInscrire() {
		return inscrire;
	}
	public void setInscrire(List<Inscrire> inscrire) {
		this.inscrire = inscrire;
	}
	public Etudiant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

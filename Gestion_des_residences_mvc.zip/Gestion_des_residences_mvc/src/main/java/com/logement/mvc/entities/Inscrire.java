package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="INSCRIPTION")
public class Inscrire implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="CODE_INSCRIPTION")
	private Long id_inscription;
    @Column(name="DATE_INSCRIPTION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date date_inscription;
    
    @ManyToOne
	@JoinColumn(name="id_etudiant")
    private Etudiant etudiants;
    
    @ManyToOne
	@JoinColumn(name="id_residence")
    private Residence residences;
    
	public Long getId_inscription() {
		return id_inscription;
	}
	public void setId_inscription(Long id_inscription) {
		this.id_inscription = id_inscription;
	}
	public Date getDate_inscription() {
		return date_inscription;
	}
	public void setDate_inscription(Date date_inscription) {
		this.date_inscription = date_inscription;
	}
	
	public Etudiant getEtudiants() {
		return etudiants;
	}
	public void setEtudiants(Etudiant etudiants) {
		this.etudiants = etudiants;
	}
	public Residence getResidences() {
		return residences;
	}
	public void setResidences(Residence residences) {
		this.residences = residences;
	}
	public Inscrire() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

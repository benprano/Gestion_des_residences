package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="CHAMBRES")
public class Chambre implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Code_Chambre")
	private Long id_chambre;
	@Column(name="CAPACITE_CHAMBRE")
	private Integer capacite_chambre;
	@Column(name="NOMBRE_PLACES_LIBRES")
	private Integer nbre_places_libres;
	@Column(name="PRIX_CHAMBRE")
	private Integer prix_chambre;
	@Column(name="CATEGORIE_CHAMBRE")
	private String categorie_chambre;
	
	@ManyToOne
	@JoinColumn(name="id_bloc")
	private Bloc blocs;
	
    @OneToMany(mappedBy="chambres")
	private List<Affecter> affecters;
	
	public Long getId_chambre() {
		return id_chambre;
	}
	public void setId_chambre(Long id_chambre) {
		this.id_chambre = id_chambre;
	}
	public Integer getCapacite_chambre() {
		return capacite_chambre;
	}
	public void setCapacite_chambre(Integer capacite_chambre) {
		this.capacite_chambre = capacite_chambre;
	}
	public Integer getNbre_places_libres() {
		return nbre_places_libres;
	}
	public void setNbre_places_libres(Integer nbre_places_libres) {
		this.nbre_places_libres = nbre_places_libres;
	}
	public Integer getPrix_chambre() {
		return prix_chambre;
	}
	public void setPrix_chambre(Integer prix_chambre) {
		this.prix_chambre = prix_chambre;
	}
	public String getCategorie_chambre() {
		return categorie_chambre;
	}
	public void setCategorie_chambre(String categorie_chambre) {
		this.categorie_chambre = categorie_chambre;
	}
	public Bloc getBlocs() {
		return blocs;
	}
	public void setBlocs(Bloc blocs) {
		this.blocs = blocs;
	}
	
	public List<Affecter> getAffecters() {
		return affecters;
	}
	public void setAffecters(List<Affecter> affecters) {
		this.affecters = affecters;
	}
	public Chambre() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

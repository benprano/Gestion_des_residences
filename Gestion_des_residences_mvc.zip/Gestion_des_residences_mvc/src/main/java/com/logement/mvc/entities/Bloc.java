package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="BLOCS")
public class Bloc implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CODE_BLOC")
	private Long id_bloc;
	@Column(name="NOM_BLOC")
	private String nom_bloc;
	@Column(name="NOMBRE_CHAMBRES")
	private Integer nbre_chambre;
	@ManyToOne
    @JoinColumn(name="id_residence")
	private Residence residences;
	@OneToMany(mappedBy="blocs")
	private List<Chambre> chambres;
	
	public Long getId_bloc() {
		return id_bloc;
	}
	public void setId_bloc(Long id_bloc) {
		this.id_bloc = id_bloc;
	}
	public String getNom_bloc() {
		return nom_bloc;
	}
	public void setNom_bloc(String nom_bloc) {
		this.nom_bloc = nom_bloc;
	}
	public Integer getNbre_chambre() {
		return nbre_chambre;
	}
	public void setNbre_chambre(Integer nbre_chambre) {
		this.nbre_chambre = nbre_chambre;
	}
	public Residence getResidences() {
		return residences;
	}
	public void setResidences(Residence residences) {
		this.residences = residences;
	}
	public List<Chambre> getChambres() {
		return chambres;
	}
	public void setChambres(List<Chambre> chambres) {
		this.chambres = chambres;
	}
	public Bloc() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="OPERATIONS")
public class Operations implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="CODE_OPERATION")
	private Long id_operation;
    @Column(name="DESCRIPTION")
	private String nature_operation;
    @Column(name="MOTIF")
	private String motif;
    @Column(name="DATE_OPERATION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date date_operation;
    @ManyToOne
    @JoinColumn(name="id_etudiant")
    private Etudiant etudiant;
    
	public Long getId_operation() {
		return id_operation;
	}
	public void setId_operation(Long id_operation) {
		this.id_operation = id_operation;
	}
	public String getNature_operation() {
		return nature_operation;
	}
	public void setNature_operation(String nature_operation) {
		this.nature_operation = nature_operation;
	}
	public String getMotif() {
		return motif;
	}
	public void setMotif(String motif) {
		this.motif = motif;
	}
	public Date getDate_operation() {
		return date_operation;
	}
	public void setDate_operation(Date date_operation) {
		this.date_operation = date_operation;
	}
	public Etudiant getEtudiant() {
		return etudiant;
	}
	public void setEtudiant(Etudiant etudiant) {
		this.etudiant = etudiant;
	}
	public Operations() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}

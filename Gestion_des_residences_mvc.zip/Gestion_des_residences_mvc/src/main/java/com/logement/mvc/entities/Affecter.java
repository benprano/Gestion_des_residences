package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="AFFECTATION")
public class Affecter implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="CODE_AFFECTATION")
	private Long id_affectation;
    @Column(name="DATE_AFFECTATION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date date_affectation;
    
    @ManyToOne
	@JoinColumn(name="id_etudiant")
    private Etudiant etudiants;
    
    @ManyToOne
	@JoinColumn(name="id_chambre")
    private Chambre chambres;
    
	public Long getId_affectation() {
		return id_affectation;
	}
	public void setId_affectation(Long id_affectation) {
		this.id_affectation = id_affectation;
	}
	public Date getDate_affectation() {
		return date_affectation;
	}
	public void setDate_affectation(Date date_affectation) {
		this.date_affectation = date_affectation;
	}
	
	
	public Etudiant getEtudiants() {
		return etudiants;
	}
	public void setEtudiants(Etudiant etudiants) {
		this.etudiants = etudiants;
	}
	public Chambre getChambres() {
		return chambres;
	}
	public void setChambres(Chambre chambres) {
		this.chambres = chambres;
	}
	
	public Affecter() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

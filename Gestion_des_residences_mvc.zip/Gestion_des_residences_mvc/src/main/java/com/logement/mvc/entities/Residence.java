package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="RESIDENCES")
public class Residence implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CODE_RESIDENCE")
	private Long id_residence;
	@Column(name="NOM_RESIDENCE")
	private String nom_residence;
	@Column(name="ADRESSE_RESIDENCE")
	private String addresse_residence;
	@Column(name="CAPACITE")
	private Integer capacite_residence;
	@Column(name="NOM_DIRECTEUR")
	private String nom_directeur;
	@Column(name="PRENOM_DIRECTEUR")
	private String prenom_directeur;
	
	@OneToMany(mappedBy="residences")
	private List<Bloc> blocs;
	
	@OneToMany(mappedBy="residences")
	private List<Inscrire> inscrires;
	
	public Long getId_residence() {
		return id_residence;
	}
	public void setId_residence(Long id_residence) {
		this.id_residence = id_residence;
	}
	public String getNom_residence() {
		return nom_residence;
	}
	public void setNom_residence(String nom_residence) {
		this.nom_residence = nom_residence;
	}
	public String getAddresse_residence() {
		return addresse_residence;
	}
	public void setAddresse_residence(String addresse_residence) {
		this.addresse_residence = addresse_residence;
	}
	public Integer getCapacite_residence() {
		return capacite_residence;
	}
	public void setCapacite_residence(Integer capacite_residence) {
		this.capacite_residence = capacite_residence;
	}
	public String getNom_directeur() {
		return nom_directeur;
	}
	public void setNom_directeur(String nom_directeur) {
		this.nom_directeur = nom_directeur;
	}
	public String getPrenom_directeur() {
		return prenom_directeur;
	}
	public void setPrenom_directeur(String prenom_directeur) {
		this.prenom_directeur = prenom_directeur;
	}
	public List<Bloc> getBlocs() {
		return blocs;
	}
	public void setBlocs(List<Bloc> blocs) {
		this.blocs = blocs;
	}
	public List<Inscrire> getInscrires() {
		return inscrires;
	}
	public void setInscrires(List<Inscrire> inscrires) {
		this.inscrires = inscrires;
	}
	public Residence() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
